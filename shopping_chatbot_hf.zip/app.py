import streamlit as st
import numpy as np
import tensorflow as tf
import nltk
from nltk.stem import WordNetLemmatizer
import pickle
import json
import random

nltk.download('punkt')
nltk.download('wordnet')

lemmatizer = WordNetLemmatizer()

with open('intents.json') as file:
    intents = json.load(file)

model = tf.keras.models.load_model('chatbot_model.h5')
words = pickle.load(open('words.pkl', 'rb'))
classes = pickle.load(open('classes.pkl', 'rb'))

def clean_up_sentence(sentence):
    sentence_words = nltk.word_tokenize(sentence)
    sentence_words = [lemmatizer.lemmatize(word.lower()) for word in sentence_words]
    return sentence_words

def bow(sentence, words):
    sentence_words = clean_up_sentence(sentence)
    bag = [1 if w in sentence_words else 0 for w in words]
    return np.array(bag)

def predict_class(sentence):
    bow_vector = bow(sentence, words)
    bow_vector = np.expand_dims(bow_vector, axis=0)
    res = model.predict(bow_vector)[0]
    threshold = 0.25
    results = [[i, r] for i, r in enumerate(res) if r > threshold]
    results.sort(key=lambda x: x[1], reverse=True)
    return [{"intent": classes[r[0]], "probability": str(r[1])} for r in results]

def get_response(intents_list, intents_json):
    if not intents_list:
        return "Sorry, I didn't understand that. Can you rephrase?"
    tag = intents_list[0]['intent']
    for intent in intents_json['intents']:
        if intent['tag'] == tag:
            return random.choice(intent['responses'])

st.set_page_config(page_title="Shopping Chatbot", layout="centered")
st.title("🛍️ Shopping Chatbot")

user_input = st.text_input("You:", "")

if st.button("Send"):
    if user_input:
        intents_result = predict_class(user_input)
        response = get_response(intents_result, intents)
        st.text_area("Bot:", value=response, height=100)